#초기 focus_value 값이 95 전원이 들어오면 95로 설정
#초기 zoom_value 값이 90 전원이 들어오면 1로 설정

#네트워크 설정 필요
import tkinter as tk
import socket

class EtherCtlApp:
    def __init__(self, root):
        self.root = root                # 인스턴스 변수 초기화 -> tkinter의 tk 객체 저장
        self.root.title("이더넷 서보모터 제어")     # 윈도우 제목
        self.root.geometry("700x550")             # 윈도우 크기
        self.root.resizable(False,False)         # 윈도우 크기 고정시키기

        self.init_widgets()              # 버튼 및 위젯 초기화
        self.set_initial_values()        # 초기 값을 설정

    def init_widgets(self):
        # 가로 1, 2, 3, 4, 5 버튼
        self.buttons_horizontal = []
        button_x_positions = [45, 130, 215, 300, 385]
        for i in range(1, 6):
            btn = tk.Button(self.root, text=f"{i}", width=10, height=1, command=lambda i=i: self.on_horizontal_button_click(i))
            btn.place(x=button_x_positions[i-1], y=360)
            self.buttons_horizontal.append(btn)

        # 수평 스크롤바
        self.h_scroll = tk.Scale(self.root, from_=1, to=150, orient=tk.HORIZONTAL, showvalue=False, length=420, command=self.on_hscroll)
        self.h_scroll.place(x=45, y=400)

        # Zoom_value1 라벨과 일반 텍스트 상자
        self.zoom_label = tk.Label(self.root, text="Zoom_value1")
        self.zoom_label.place(x=55, y=440)
        self.zoom_value_label = tk.Label(self.root, text="0", font=("Arial", 14), width=8, anchor='center', relief='sunken')
        self.zoom_value_label.place(x=155, y=440)

        # Focus_value2 라벨과 일반 텍스트 상자
        self.focus_label = tk.Label(self.root, text="Focus_value2")
        self.focus_label.place(x=565, y=400)
        self.focus_value_label = tk.Label(self.root, text="95", font=("Arial", 14), width=8, anchor='center', relief='sunken')
        self.focus_value_label.place(x=560, y=440)

        # 수직 스크롤바
        self.v_scroll = tk.Scale(self.root, from_=255, to=1, orient=tk.VERTICAL, showvalue=False, length=310, command=self.on_vscroll)
        self.v_scroll.place(x=500, y=50)

        # 세로 CW_MAX, CW, STOP, CCW, CCW_MAX 버튼
        self.buttons_vertical = []
        button_names = ["CCW_MAX", "CCW", "STOP", "CW", "CW_MAX"]
        button_y_positions = [50, 120.15, 190.3, 260.45, 335]
        for name, y in zip(button_names, button_y_positions):
            btn = tk.Button(self.root, text=name, width=10, height=1, command=lambda name=name: self.on_vertical_button_click(name))
            btn.place(x=580, y=y)
            self.buttons_vertical.append(btn)

        # 확인 및 취소 버튼
        self.ok_button = tk.Button(self.root, text="확인", width=10, height=2)
        self.ok_button.place(x=250, y=500)

        self.cancel_button = tk.Button(self.root, text="취소", width=10, height=2, command=self.root.quit)
        self.cancel_button.place(x=400, y=500)

        # 여기 까지가 전체적인 UI 설정

    def set_initial_values(self):
        initial_zoom_value = 90      # 초기 zoom 값 75
        initial_focus_value = 1    # 초기 Focus 값 1

        self.h_scroll.set(initial_zoom_value)       # 수평 스크롤 바 초기 값 대입
        self.v_scroll.set(initial_focus_value)      # 수직 스크롤 바 초기 값 대입
        self.update_zoom_value_label(initial_zoom_value)    # 값을 보여주는 메세지에 초기 값을 표시
        self.update_focus_value_label(initial_focus_value)  # 값을 보여주는 메세지에 초기 값을 표시
        self.send_value_to_socket(24, initial_zoom_value)  # 24 포트로 Focus_value2 전송
        self.send_value_to_socket(23, initial_focus_value)  # 24 포트로 Focus_value2 전송

    def on_hscroll(self, value):        # 수평 스크롤 바를 움직였을 때 해당 값 전송
        value = int(float(value))       # String -> float -> int로 변환
        self.update_zoom_value_label(value)     # 수평 스크롤바 현재 값 위에서 정수로 변환 된 값을 Zoom_value1에 업데이트
        self.send_value_to_socket(24, value)    # Zoom_value1 값 전송

    def on_vscroll(self, value):        # 수직 스크롤 바를 움직였을 때 해당 값 전송
        value = int(float(value))       # String -> float -> int로 변환
        self.update_focus_value_label(value)    # 수평 스크롤바 현재 값 위에서 정수로 변환 된 값을 Focus_value2에 업데이트
        self.send_value_to_socket(23, value)    # Focus_value2 값 전송

    def on_horizontal_button_click(self, button_id):        # 가로 버튼 클릭시 값 호출, 클릭된 버튼의 ID에 따라 Zoom_value1 값 설정
        current_value = self.h_scroll.get()
        value = current_value
        if button_id == 1:
            value = 1
        elif button_id == 2:
            value = 45
        elif button_id == 3:
            value = 90
        elif button_id == 4:
            value = 75
        elif button_id == 5:
            value = 150
        self.h_scroll.set(value)
        self.update_zoom_value_label(value)
        self.send_value_to_socket(24, value)    # Zoom_value 값 전송

    def on_vertical_button_click(self, button_name):        # 위와 동일
        current_value = self.v_scroll.get()
        value = current_value
        if button_name == "CW_MAX":     # 시계 방향
            value = 1
        elif button_name == "CW":
            value = 25
        elif button_name == "STOP":
            value = 50
        elif button_name == "CCW":
            value = 75
        elif button_name == "CCW_MAX":      # 반 시계 방향
            value = 255
        self.v_scroll.set(value)
        self.update_focus_value_label(value)
        self.send_value_to_socket(23, value)  # Focus_value 값 전송

    def update_zoom_value_label(self, value):               # Zoom_value 라벨의 텍스트 업데이트
        self.zoom_value_label.config(text=str(value))

    def update_focus_value_label(self, value):              # focus_value 라벨의 텍스트 업데이트
        self.focus_value_label.config(text=str(value))

    def send_value_to_socket(self, port, value):        # 지정된 포트로 값을 전송 하는 소켓 메서드
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect(('192.168.6.201', port))
                s.sendall(value.to_bytes(2, byteorder='little'))        # value를 2byte로 변환, 1byte는 1~255까지가 최대 256 이후 부터 2byte로 변환 (256 이상의 값을 줄 시 모터가 시계 방향의 끝 값인 1이되어 움직임)
        except OSError as e:                            # 에러 호출
            print(f"Socket error: {e}")

def main():             # 메인 루프 시작 EtherCtlAp 클래스의 인스턴스 생성 root 윈도우 실행
    root = tk.Tk()
    app = EtherCtlApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
